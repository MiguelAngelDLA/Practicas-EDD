/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author migue
 */
public class Fila{
    //Atributos
    Dato[] arregloDatos;
    int tope;
    
    public Fila(){
        this.arregloDatos = null;
        this.tope = 0;
    }

    public Fila(int tamaño) {
        this.arregloDatos = new Dato[tamaño];
        this.tope = 0;
    }
    
    public boolean isFilaEmpty(){
        if(tope == 0) return true;
        else return false;
    }
    
    public boolean isFilaFull(){
        return tope == arregloDatos.length;
    }
    
    public void push(Dato dato){
        if(tope < arregloDatos.length) arregloDatos[tope++] = dato;
        else JOptionPane.showMessageDialog(null, "No hay espacio");
    }
    
    public Dato pop(){
        Dato oRet;
        if(!isFilaEmpty()){
            oRet = arregloDatos[--tope];
        }
        else{ 
            oRet = null;
            JOptionPane.showMessageDialog(null, "La pila esta vacia");
        }
        return oRet;
    }
    
    public void mostrar(JTable tabla){
        DefaultTableModel modelo = (DefaultTableModel)tabla.getModel();
        if(!isFilaEmpty()){
            int contador = tope;
            modelo.setRowCount(tope);
            Fila auxFila = new Fila(this.tope);
            Dato oDato = new Dato();
            
            for(int i = 0; i < contador; i++){
                oDato = this.pop();
                oDato.mostrarDato(tabla, i);
                auxFila.push(oDato);
            }
            
            while(!auxFila.isFilaEmpty()){
                this.push(auxFila.pop());
            }
        }
        else{            
            modelo.setRowCount(0);
            JOptionPane.showMessageDialog(null, "No hay elementos para mostrar");
        }
    }
    
    public void invertirFila(){
        if(!isFilaEmpty()){
            Fila auxFila = new Fila(tope);
            Fila auxFila1 = new Fila(tope);
            
            while(!isFilaEmpty())
                auxFila.push(pop());
            
            while(!auxFila.isFilaEmpty())
                auxFila1.push(auxFila.pop());
            
            while(!auxFila1.isFilaEmpty())
                push(auxFila1.pop());
        }
        else{
            JOptionPane.showMessageDialog(null, "La pila esta vacia");
        }
    }
    
    public void popBottomElement(){
        if(tope >= 2){
            invertirFila();
            pop();
            invertirFila();
        }
        else JOptionPane.showMessageDialog(null, "Se necesitan minimo 2 elementos para hacer esta acción");
    }
    
    public void eliminarElemento(int posicion){
        Fila auxFila = new Fila(tope-posicion);
        if( posicion > 0 && posicion <= tope){
            while(!auxFila.isFilaFull())
                auxFila.push(pop());
            
            pop();
            while(!auxFila.isFilaEmpty())
                push(auxFila.pop());
        }
    }
    
    public void agregaElemento(int posicion, Dato dato){
        Fila auxFila = new Fila(tope + 1);
        int counter = tope + 1;
        if(!isFilaFull()){
            while(!auxFila.isFilaFull()){
                if(posicion != counter)
                    auxFila.push(pop());
                else
                    auxFila.push(dato);
                counter--;
            }
 
            while(!auxFila.isFilaEmpty())
                push(auxFila.pop());
            
        }
        else JOptionPane.showMessageDialog(null, "La pila está llena");
    }
    
    public void ordenarPila(Fila stack)
    {
        
        // base case: stack is empty
        if (stack.isFilaEmpty()) {
            return;
        }
 
        // remove the top element
        Dato top = stack.pop();
 
        // recur for the remaining elements in the stack
        ordenarPila(stack);
 
        // insert the popped element back into the sorted stack
        sortedInsert(stack, top);
    }
    
    public void sortedInsert(Fila stack, Dato oDato)
    {
        // base case: if the stack is empty or
        // the key is greater than all elements in the stack
        if (stack.isFilaEmpty()|| oDato.getprioridad() >tope)
        {
            stack.push(oDato);
            return;
        }
 
        Dato top = stack.pop();
 
        sortedInsert(stack, oDato);
 
        stack.push(top);
    }
    
    
}
