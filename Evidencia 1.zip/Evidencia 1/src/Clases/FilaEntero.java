/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author migue
 */
public class FilaEntero {
    private int[] arregloEntero;
    private int tope;
    
    public FilaEntero(){
        this.arregloEntero = null;
        this.tope = 0;
    }

    public FilaEntero(int tamaño) {
        this.arregloEntero = new int[tamaño];
        this.tope = 0;
    }
    
    public boolean isFilaEnteroEmpty(){
        if(tope == 0) return true;
        else return false;
    }
    
    public boolean isFilaEnteroFull(){
        return tope == arregloEntero.length;
    }
    
    public void push(int dato){
        if(tope < arregloEntero.length) arregloEntero[tope++] = dato;
        else System.out.println("No hay espacio");
    }
    
    public int pop(){
        int oRet;
        if(!isFilaEnteroEmpty()){
            oRet = arregloEntero[--tope];
        }
        else{ 
            oRet = 0;
            System.out.println("La pila esta vacia");
        }
        return oRet;
    }
    
    public void mostrar(){
        if(!isFilaEnteroEmpty()){
            int contador = tope;
            FilaEntero auxFilaEntero = new FilaEntero(this.tope);
            int aux;
            
            for(int i = 0; i < contador; i++){
                aux = this.pop();
                System.out.println(aux);
                auxFilaEntero.push(aux);
            }
            
            while(!auxFilaEntero.isFilaEnteroEmpty()){
                this.push(auxFilaEntero.pop());
            }
        }
        else{            
            System.out.println("No hay elementos para mostrar");
        }
    }
    
    public void invertirFilaEntero(){
        if(!isFilaEnteroEmpty()){
            FilaEntero auxFilaEntero = new FilaEntero(tope);
            FilaEntero auxFilaEntero1 = new FilaEntero(tope);
            
            while(!isFilaEnteroEmpty())
                auxFilaEntero.push(pop());
            
            while(!auxFilaEntero.isFilaEnteroEmpty())
                auxFilaEntero1.push(auxFilaEntero.pop());
            
            while(!auxFilaEntero1.isFilaEnteroEmpty())
                push(auxFilaEntero1.pop());
        }
        else{
            System.out.println("La pila esta vacia");
        }
    }
    
    public void sortedInsert(FilaEntero stack, int key)
    {
        // caso base: si la stack está vacía o
        // la clave es mayor que todos los elementos de la stack
        if (stack.isFilaEnteroEmpty() || key > stack.tope)
        {
            stack.push(key);
            return;
        }
 
        /* Llegamos aquí cuando la clave es más pequeña que el elemento superior */
 
        // elimina el elemento superior
        int top = stack.pop();
 
        // recurre para los elementos restantes en la stack
        sortedInsert(stack, key);
 
        // inserta el elemento reventado de nuevo en la stack
        stack.push(top);
    }
 
    // Método recursivo para ordenar una stack
    public void sortStack(FilaEntero stack)
    {
        // caso base: la stack está vacía
        if (stack.isFilaEnteroEmpty()) {
            return;
        }
 
        // elimina el elemento superior
        int top = stack.pop();
 
        // recurre para los elementos restantes en la stack
        sortStack(stack);
 
        // inserta el elemento reventado de nuevo en la stack ordenada
        sortedInsert(stack, top);
    }
}

