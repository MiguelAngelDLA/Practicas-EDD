/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejecutables;

import Clases.FilaEntero;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author migue
 */
public class Consola {
        static FilaEntero fila;
        static int tope = 0, minLlegada = 0, maxLlegada= 0, minRespuesta = 0, maxRespuesta = 0, contador = 0;
        static Scanner teclado = new Scanner(System.in);
        static Random random = new Random();
        
        public static void main(String[] args){
        String[] opciones = {"1- Establecer tope de fila",
                            "2- Establecer rango de tiempo de llegada",
                            "3- Establecer rango de tiempo de respuesta",
                            "4- Ejecutar",
                            "5- Salir"};
        int opcion;
            while (true){
                imprimir(opciones);
                opcion = teclado.nextInt();
                
                switch(opcion){
                    case 1:
                        imprimir("Ingrese el tope de la fila");
                        tope = teclado.nextInt();
                        break;
                    case 2:
                        imprimir("Ingrese tiempo minimo de llegada (segundos)");
                        minLlegada = teclado.nextInt();
                        imprimir("Ingrese tiempo maximo de llegada (segundos)");
                        maxLlegada = teclado.nextInt();
                        break;
                    case 3:
                        imprimir("Ingrese tiempo minimo de respuesta (segundos)");
                        minRespuesta = teclado.nextInt();
                        imprimir("Ingrese tiempo maximo de respuesta (segundos)");
                        maxRespuesta = teclado.nextInt();
                        break;
                    case 4:
                        if(tope == 0 || minLlegada == 0 || maxLlegada == 0 || minRespuesta == 0 || maxRespuesta == 0)
                        {
                            imprimir("Porfavor verifique que la información que haya insertado sea correcta y que no sea igual a 0");
                        }
                        else{
                            imprimir("Iniciando programa...");
                            try{
                                fila = new FilaEntero(tope);
                                while(contador < 180){
                                    TimeUnit.SECONDS.sleep(1);
                                    realizarAccion();
                                    contador++;
                                }
                                imprimir("El proceso ha sido terminado");
                            }catch(InterruptedException e){
                            System.out.println("Hubo un error");
                            }
                        }
                        break;
                    case 5:
                        
                        break;
                }
            }
            
            
        }
        
        public static void imprimir(String text){
            System.out.println(text);
        }
        
        public static void imprimir(String[] options){
            for (String option : options){
                System.out.println(option);
            }
            System.out.print("Elija su opción: ");
        }
        
        static void agregarElemento(){
            try{
                if(fila.isFilaEnteroFull()){
                    System.out.println("Un numero ha sido rechazado");
                }
                Thread.sleep((minLlegada + (random.nextInt(maxLlegada) - minLlegada)) * 1000);
                int prioridad = (1 + random.nextInt(5));
                fila.push(prioridad);
                fila.sortStack(fila);
                imprimir("Se agregó el numero " + prioridad);
            }catch(InterruptedException e){
                imprimir(e.toString());
            }
        }
        
        
        public static void realizarAccion() {
            boolean flag = random.nextInt(2) == 1;  
            if(flag || fila.isFilaEnteroEmpty()){
                agregarElemento();
                fila.mostrar();
            }
            else{
                quitar();
                fila.mostrar();
            }
        }
        
        static void quitar(){
            try{
            if(fila.isFilaEnteroFull()){
                System.out.println("Un numero ha sido rechazado");
            }
            Thread.sleep((minLlegada + (random.nextInt(maxLlegada) - minLlegada)) * 1000);
            int quitado = fila.pop();
            fila.sortStack(fila);
            imprimir("Se quito el numero " + quitado);
            }catch(InterruptedException e){
                imprimir(e.toString());
            }
        }

}
        

